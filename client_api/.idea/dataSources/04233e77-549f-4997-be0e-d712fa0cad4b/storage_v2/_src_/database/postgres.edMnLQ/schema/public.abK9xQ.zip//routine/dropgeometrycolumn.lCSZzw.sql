create function dropgeometrycolumn(table_name character varying, column_name character varying)
  returns text
strict
language plpgsql
as $$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;

comment on function dropgeometrycolumn(varchar, varchar)
is 'args: table_name, column_name - Removes a geometry column from a spatial table.';

alter function dropgeometrycolumn(varchar, varchar)
  owner to postgres;

