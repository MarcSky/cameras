create function st_setvalues(rast raster, nband integer, x integer, y integer, newvalueset double precision[], noset boolean[] DEFAULT NULL::boolean[], keepnodata boolean DEFAULT false)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public._ST_setvalues($1, $2, $3, $4, $5, $6, FALSE, NULL, $7)
$$;

comment on function st_setvalues(raster, integer, integer, integer, double precision [], boolean [], boolean)
is 'args: rast, nband, columnx, rowy, newvalueset, noset=NULL, keepnodata=FALSE - Returns modified raster resulting from setting the values of a given band.';

alter function st_setvalues(raster, integer, integer, integer, double precision [], boolean [], boolean)
  owner to postgres;

